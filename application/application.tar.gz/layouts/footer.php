	</div>
  </div>
</div>
<!-- ============START FOOTER-CONTAINER============ -->
	<div class="footer-container">
		<div class="container">
			<div class="row">
				<div class="span12">
					<div class="footer">
						<div class="footer-block"><strong>Free Shipping</strong> on orders over $ 499. This offer is valid
                        on all our store items.
                    </div>
                    <p style="display: block;" id="back-top"><a href="#top"><span></span></a></p>

                    <div class="footer-cols-wrapper">
                        <div style="height: 219px;" class="footer-col">
                            <h4>Information</h4>

                            <div class="footer-col-content">
                                <ul>
                                    <li>
                                        <a href="http://livedemo00.template-help.com/magento_43805/about-magento-demo-store">About
                                            Us</a></li>
                                    <li><a href="http://livedemo00.template-help.com/magento_43805/customer-service">Customer
                                        Service</a></li>
                                    <li class="last privacy"><a
                                            href="http://livedemo00.template-help.com/magento_43805/privacy-policy-cookie-restriction-mode">Privacy
                                        Policy</a></li>
                                </ul>
                                <ul class="links">
                                    <li class="first"><a
                                            href="http://livedemo00.template-help.com/magento_43805/catalog/seo_sitemap/category/"
                                            title="Site Map">Site Map</a></li>
                                    <li>
                                        <a href="http://livedemo00.template-help.com/magento_43805/catalogsearch/term/popular/"
                                           title="Search Terms">Search Terms</a></li>
                                    <li>
                                        <a href="http://livedemo00.template-help.com/magento_43805/catalogsearch/advanced/"
                                           title="Advanced Search">Advanced Search</a></li>
                                    <li><a href="http://livedemo00.template-help.com/magento_43805/sales/guest/form/"
                                           title="Orders and Returns">Orders and Returns</a></li>
                                    <li class=" last"><a
                                            href="http://livedemo00.template-help.com/magento_43805/contacts/"
                                            title="Contact Us">Contact Us</a></li>
                                </ul>
                            </div>
                        </div>
                        <div style="height: 219px;" class="footer-col">
                            <h4>Why buy from us</h4>

                            <div class="footer-col-content">
                                <ul>
                                    <li><a href="#">Shipping &amp; Returns</a></li>
                                    <li><a href="#">Secure Shopping</a></li>
                                    <li><a href="#">International Shipping</a></li>
                                    <li><a href="#">Affiliates</a></li>
                                    <li><a href="#">Group Sales</a></li>
                                </ul>
                            </div>
                        </div>
                        <div style="height: 219px;" class="footer-col">
                            <h4>My account</h4>

                            <div class="footer-col-content">
                                <ul>
                                    <li>
                                        <a href="http://livedemo00.template-help.com/magento_43805/customer/account/login/">Sign
                                            In</a></li>
                                    <li><a href="http://livedemo00.template-help.com/magento_43805/checkout/cart/">View
                                        Cart</a></li>
                                    <li><a href="http://livedemo00.template-help.com/magento_43805/wishlist/">My
                                        Wishlist</a></li>
                                    <li><a href="#">Track My Order</a></li>
                                    <li><a href="#">Help</a></li>
                                </ul>
                            </div>
                        </div>
                        <div style="height: 219px;" class="footer-col last">
                            <h4>Contacts</h4>

                            <div class="footer-col-content">
                                <p>8901 Marmora Road, Glasgow, D04 89GR</p>
                                <span class="tel">1-(800)-234-5678</span>
                                <ul class="list-icon">
                                    <li><a target="_blank" href="https://twitter.com/"><img src="<?php echo base_url();?>public/images/frontend/twitter.png"
                                                                                            alt=""></a></li>
                                    <li><a target="_blank" href="http://www.facebook.com/"><img
                                            src="<?php echo base_url();?>public/images/frontend/facebook.png" alt=""></a></li>
                                    <li><a target="_blank" href="#"><img src="<?php echo base_url();?>public/images/frontend/rss.png" alt=""></a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <address>©
                        <script type="text/javascript">var mdate = new Date();
                        document.write(mdate.getFullYear());</script>
                        2014 Magento Demo Store. All Rights Reserved.
                    </address>
                    <div class="clear"></div>
                    <div class="paypal-logo">
                        <a href="#" title="Additional Options"
                           onclick="javascript:window.open('https://www.paypal.com/us/cgi-bin/webscr?cmd=xpt/Marketing/popup/OLCWhatIsPayPal-outside','paypal','width=600,height=350,left=0,top=0,location=no,status=yes,scrollbars=yes,resizable=yes'); return false;"><img
                                src="<?php echo base_url();?>public/images/frontend/paypal.gif" alt="Additional Options"
                                title="Additional Options"></a>
                    </div><!-- -->
					</div>
				</div>
			</div>
		</div>
	</div><!-- end footer-container -->
</div><!-- end div page -->
</div><!-- end div wraper -->
</body>
</html>