<div class="container">
    <div class="span12">
      <?php echo $content_for_layout; ?>
    </div>
</div>